#!/bin/bash

FILE=$1
NUM=$2
OUTPUT_FILE=output_hbo_api_testing.txt

usage() {
	echo "Usage: $0 <file of URLs> <number of requests to do per URL> [-v]"  >&2
}

die() {
	echo "$1" >&2
	[ "$2" != "" ] && exit $2
	exit 1
}

output() {
	[ "$VERBOSE" == 1 ] && echo $2 "$1"
}

[ "$FILE" == "" ] && usage && die "You must specify a file of URLs to perform the load testing against API endpoints."
[ "$NUM" == "" ] && usage && die "You must specify the number of times to perform the request for each API endpoint."
[ ! -r "$FILE" ] && die "ERROR: File '$FILE' does not exist or is not readable."

function post_to_slack() {

SLACK_MESSAGE="\`\`\`$1\`\`\`"
SLACK_URL=https://hooks.slack.com/services/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
SLACK_ICON=':slack:'

#curl -X POST --data "payload={\"text\": \"${SLACK_ICON} ${SLACK_MESSAGE}\"}" ${SLACK_URL}
curl -F file=@$OUTPUT_FILE -F initial_comment=API-TEST-SUCCESS -F channels=#myslackchannel -F token=xoxp-3462765199-138185897680-140165309828-0a8baac47a087a20973053ab43483754 https://slack.com/api/files.upload -s > /dev/null 

}


# Gather some stats from input file
STATS_URL_COUNT=$(wc -l "$FILE" | awk '{print $1}')
STATS_REQUEST_COUNT=$(($STATS_URL_COUNT * $2))

for url in $(cat $FILE); do

	output "----"
	output "URL: $url\n"

	run=1

	echo -n "\"$url\"," >> $OUTPUT_FILE 
	chmod 777 $OUTPUT_FILE

	while [ $run -lt $(($NUM+1)) ]; do

		output "  Request #$run: " -n

		CURL_RESPONSE=$(/usr/bin/curl -u admin:admin $url -s)
		CURL_STATUS=$?
		echo "********************START OF RESPONSE $run******************************" >> $OUTPUT_FILE
		echo $CURL_RESPONSE >> $OUTPUT_FILE
		echo "********************END OF RESPONSE $run******************************" >> $OUTPUT_FILE


		# Check curl returned OK
		if [ $CURL_STATUS -gt 0 ]; then
			output "curl error $CURL_STATUS"
			echo -n "\"err: curl: $CURL_STATUS\"," >> $OUTPUT_FILE
			run=$((run+1))
			continue
		fi

		# Check that it was a 200 OK
		if [ $(echo "$CURL_RESPONSE" |grep 'OK' |wc -l |awk '{print $1}') -lt 1 ]; then
			HTTP_RETURN_STATUS=$(echo "$CURL_RESPONSE" |grep -E '^HTTP')
			output "$HTTP_RETURN_STATUS"
			echo -n "\"err: $HTTP_RETURN_STATUS\"," >> $OUTPUT_FILE
			run=$((run+1))
			continue
		fi

		run=$((run+1))

	done
	echo "" >> $OUTPUT_FILE

done
#post_to_slack "API execution success" 
post_to_slack 
